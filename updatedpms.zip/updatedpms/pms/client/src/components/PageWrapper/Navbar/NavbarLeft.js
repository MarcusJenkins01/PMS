function NavbarLeft() {
  return (
    <div className="navbar-left">
      <a className="brand" href="/book">PMS</a>
    </div>
  );
}

export default NavbarLeft;
