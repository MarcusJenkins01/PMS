import BookingForm from "./BookingForm";

const BookingPage = (props) => {
  return (
    <BookingForm></BookingForm>
  );
}

export default BookingPage;
