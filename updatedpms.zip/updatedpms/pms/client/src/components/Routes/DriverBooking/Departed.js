import SubTitle from '../../Shared/SubTitle';

import './DriverBooking.css';

const Departed = (props) => {
  return(
    <div id="departed">
      Thank you for booking with us
    </div>
  );
}

export default Departed;
