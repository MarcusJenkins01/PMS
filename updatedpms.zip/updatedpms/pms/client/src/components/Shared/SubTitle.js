import './Shared.css';

const SubTitle = (props) => {
  return (
    <div className="sub-title">{props.children}</div>
  );
}

export default SubTitle;
