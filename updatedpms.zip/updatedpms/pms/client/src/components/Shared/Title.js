import './Shared.css';

const Title = (props) => {
  return (
    <div className="page-title">{props.children}</div>
  );
}

export default Title;
