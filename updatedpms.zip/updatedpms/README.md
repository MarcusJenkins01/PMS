# PMS

In order to run the clientside and serverside concurrently, use the command:

`npm run all`
