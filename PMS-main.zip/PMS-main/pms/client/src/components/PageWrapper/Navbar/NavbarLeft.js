function NavbarLeft() {
  return (
    <div className="navbar-left">
      <a className="brand" href="/">PMS</a>
    </div>
  );
}

export default NavbarLeft;
