import styled from 'styled-components';
import 'bootstrap/dist/css/bootstrap.min.css';
import "./Footer.css";
import FooterButton from './FooterButton';
import logo from './logo.png';
function Footer() {
  return (
    <div className="footer">
      <div id="button"></div>
      <div id="container">
        <div id="cont">
          <div className='row'>
            <div className='col'>
              <div className="footer_center">
              {/* Column 1 */}
              <h4>Contact</h4>
              <ul className="list-unstyled">
                <li>123-456-78901</li>
                <li>Norwich, Norfolk</li>
                <li>UEA</li>
                <li>pmssupport@uea.co.cuk</li>
                </ul>
              </div>
            </div>

            <div className='col'>
              <div className="footer_left">
              {/* Column 2 */}
              <h4>About Us</h4>
              Making parking easy
              </div>
            </div>
            
            <div className='col'>
              <div className="footer_right">
              {/* Column 3 */}
              <h4>UEA PMS</h4>
              <img src={logo} height={100} width={100} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Footer;
