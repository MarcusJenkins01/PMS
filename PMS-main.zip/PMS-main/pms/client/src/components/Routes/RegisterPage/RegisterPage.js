import RegisterForm from "./RegisterForm";

function RegisterPage() {
  return (
    <RegisterForm/>
  );
}

export default RegisterPage;
